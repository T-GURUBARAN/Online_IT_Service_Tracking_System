﻿namespace Online_IT_Service_Tracking_System
{


    public partial class DataSet1
    {
    }
}
